# MagmaOsint
> Search information by username, firstname, lasname....

```
git clone https://github.com/LimerBoy/MagmaOsint
cd MagmaOsint/
pip install -r requirements.txt
python3 osint.py
```
