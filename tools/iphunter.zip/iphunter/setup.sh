clear
pip install colorama
pip install requests
clear
sleep 2
echo ""
echo -e "\e[91mInstalación finalizada.!\e[0m"
echo -e "\e[91mAhora puede ejecutar el comando: python iphunter.py\e[0m"
