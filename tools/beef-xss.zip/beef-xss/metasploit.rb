load msgrpc ServerHost=127.0.0.1 User=Darkmux Pass=CyberSpy ServerType=Web
